/**
 *
 */
package Regular_Expression;

import java.util.Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import java.util.Comparator;

public class MiniDFA extends DFA
{
    /*
        a    b  区号             a   b  区号
    1   2    3   1          1   1   2   1
    2   4    1   1          1   1   2   1
    3   2    1   2  -->     2   1   1   2
    4   3    2   2          2   2   1   3
    Serial_number = {1, 1, 2, 2}
    NewSerialNumber = {1, 1, 2, 3}
    oringinal_table_ = {2,3; 4,1; 2,1; 3,2}
    newTable = {1,1,2; 1,1,2; 2,1,1; 2,2,1}

     */
    public node[] miniDFA_ = new node[100];
    public Set<Character>alphabeta_ = new HashSet<>();
    public ArrayList<Character>ar_alphabeta_ = new ArrayList<>();
    public ArrayList<String[]> oringinal_table_ = new ArrayList<>();// 初始表 建成后始终不变
    public ArrayList<ArrayList<Integer>> newTable_ = new ArrayList<>();//新表 在LoopBuiltTable反复更新 直至满足结束条件
    public ArrayList<ArrayList<Integer>> final_table_ = new ArrayList<>(); //最终表
    public ArrayList<Boolean> isEnd = new ArrayList<Boolean>(); // 记录是否是终态
    public ArrayList<Boolean> finalIsEnd = new ArrayList<>();


    MiniDFA()
    {
        //alphabeta_ = super.alphabeta_;//无效
        //alphabeta_ = super.Get_alphabeta_(); // 无效

    }

    // 调试MiniDFA结束后将这段移植在GetTable()和GUI的main()中
    /*public static void main(String[] args)
    {
        DFA dfa = new DFA();
        dfa.draw_dfa();

        MiniDFA Mini_DFA_Class = new MiniDFA();
        Mini_DFA_Class.alphabeta_ = dfa.alphabeta_;
        for(Character a: Mini_DFA_Class.alphabeta_)
        {
            Mini_DFA_Class.ar_alphabeta_.add(a);
        }
        System.out.println("MiniDFA alphabeta_： " + Mini_DFA_Class.alphabeta_);


        Mini_DFA_Class.GetTable(dfa.dfa_, dfa.nodenum_);
        System.out.println("final_table_ : "+Mini_DFA_Class.final_table_);
        System.out.println("finalisend: "+ Mini_DFA_Class.finalIsEnd);
        Mini_DFA_Class.DrawMiniDFA();

    }*/

    /**
     *
     * @param dfalist DFA执行结束后的关系节点
     * @param num DFA节点数
     */
    public void GetTable(int num,node[] dfalist)
    {
//        DFA dfa = new DFA();
//        dfa.draw_dfa();
//        this.alphabeta_ = dfa.alphabeta_;
        for(Character a: this.alphabeta_)
        {
            this.ar_alphabeta_.add(a);
        }

//        node[] dfalist = dfa.dfa_;
//        int num = dfa.nodenum_;



        ArrayList<Integer> Serial_number = new ArrayList<>(); // 记录区号 这个函数的区号只有1（非终态） 2（终态）

        for(int i = 1; i <= num; i++)
        {
            if(dfalist[i].isEnd == true)
            {
                Serial_number.add(2);
                isEnd.add(true);
            }

            else
            {
                Serial_number.add(1);
                isEnd.add(false);
            }
            String[] temp = new String[100];
            for(int j = 0; j < dfalist[i].way.length(); j++)
            {
                // a : 代表在字母表中的顺序
                Character w = dfalist[i].way.charAt(j);
                int a = ar_alphabeta_.indexOf(w); // 当前方法（dfa节点)是字母表中第几个元素
                temp[a] = dfalist[i].next.get(j).toString(); // 将这个方法对应的的next节点添加到 table 的相应顺序
            }

            for(int k = 0; k < alphabeta_.size();k++)
            {
                if(temp[k] == null)
                    temp[k] = "-1";
            }
            oringinal_table_.add(temp); // 完成初始表的一行
        }
        //初始表完成


        for(int i = 0; i < num; i++)
        {
            ArrayList<Integer> Temprow = new ArrayList<>();
            Temprow.add(Serial_number.get(i));
            for(int j = 0; j < alphabeta_.size(); j++)
            {
                int k = GetNewNumber(i, j, Serial_number);
                Temprow.add(k);
            }
            newTable_.add(Temprow);
        }

        DrawTable(newTable_, Serial_number);
        LoopBuiltTable(Serial_number, num); // 首次调用该函数 所以递归结束后在这里
    }

    /**
     * 得到新表 第row行col列的值 即将原来状态更新为 新区号的状态
     * @param row 行
     * @param col 列
     * @param Serial_number 区号，第一期
     * @return 新的值
     */
    public int GetNewNumber(int row,int col,ArrayList<Integer> Serial_number)
    {
        String[] s = oringinal_table_.get(row);
        String c = s[col];
        int a = Integer.valueOf(c);
        int res = 0;
        if(a != -1)
            res = Serial_number.get(a-1);
        else
            res = -1;
        return res;
    }


    /**
     * 循环
     * @param Serial_number 区号，第一次进入该函数区号只有 0和 1
     * @param num 节点个数
     */
    public void LoopBuiltTable(ArrayList<Integer> Serial_number, int num)
    {
        ArrayList<Integer> newSerialNumber = new ArrayList<>();
        Set<ArrayList<Integer>> tempSet = new HashSet<>(); // 辅助创建区号

        Integer newnumber = 0; // 从1开始使用 所以 使用前++
        finalIsEnd.clear();
        // 创建新区号
        for (int i = 0; i < num; i++)
        {
            if(tempSet.add(newTable_.get(i))) // 如果添加成功 则是新的组合 则++ 第一个一定是新的
            {
                newnumber++;
                final_table_.add(newTable_.get(i));//此处仅借用final_table_,与最终值无关。
                finalIsEnd.add(isEnd.get(i));
                newSerialNumber.add(newnumber);
            }
            else
            {
                int k = final_table_.indexOf(newTable_.get(i));
                newSerialNumber.add(k+1);
            }


        }
        System.out.println("新区号" + newSerialNumber);
        DrawTable(newTable_, newSerialNumber);
        // 新区号创建结束后新表就不用了
        newTable_.clear();

        // 中间过程借用，用完恢复
        final_table_.clear();


        // 用新区号再构建新表
        for(int i = 0; i < num; i++)
        {
            ArrayList<Integer> Temprow = new ArrayList<>();
            Temprow.add(newSerialNumber.get(i));
            for(int j = 0; j < alphabeta_.size(); j++)
            {
                int k = GetNewNumber(i,j,newSerialNumber);
                Temprow.add(k);
            }
            newTable_.add(Temprow);
        }





        // 如果新区号和上次一样 建立finaltable 结束
        if(Serial_number.equals(newSerialNumber))
        {
            for (ArrayList<Integer> a : tempSet)
            {
                final_table_.add(a);
            }
            FinalSetSort();
            System.out.println("MiniDFA alphabeta_： " + alphabeta_);

            //System.out.println("final_table_ : "+final_table_);
            System.out.println("绘制最终表");
            DrawTable(final_table_, newSerialNumber);

            System.out.println("finalIsEnd: "+ finalIsEnd);
            return;
        }
        LoopBuiltTable(newSerialNumber, num);
    }


    /**
     * 绘制MiniDFA表格
     */
    public void DrawTable(ArrayList<ArrayList<Integer>> Table, ArrayList<Integer> serialnumber)
    {
        //表头 a b c
        System.out.printf("     ");//输出六个空格
        for(char a : alphabeta_)
        {
            System.out.printf("    %c", a);
        }
        System.out.printf("    区号");
        System.out.println("");

        //表
        int i = 0;
        for(ArrayList<Integer> a : Table)
        {

            for(int k : a)
            {
                System.out.printf("%,5d", k);
            }
            System.out.printf("%,5d",serialnumber.get(i));
            i = i+1;
            System.out.println("");
        }

    }

    /**
     * 为最终表排序
     */
    public void FinalSetSort()
    {
        ArrayList<Integer> temp = new ArrayList<>();
        int lenth = final_table_.size();
        for(int i = 0; i < lenth; i++)
        {
            for(int j = i+1; j < lenth; j++)
            {
                if(final_table_.get(i).get(0) > final_table_.get(j).get(0))
                {
                    temp = final_table_.get(i);
                    final_table_.set(i,final_table_.get(j));
                    final_table_.set(j,temp);
                }
            }
        }
    }

    /**
     * 生成dot脚本语言的函数
     * 即绘制MiniDFA图
     */
    public void DrawMiniDFA()
    {
        int length = final_table_.size();
        GraphVizTest gViz=new GraphVizTest("D:\\Graphviz\\MiniDFA", "D:\\Graphviz\\bin\\dot.exe");

        gViz.start_graph();
        gViz.addln("graph [rankdir=LR];"); //节点方向从做至右排列，不加从上至下排列

        for(int i = 0; i < length; i++)
        {
            String out = new String();
            if(finalIsEnd.get(i))
            {
                out += final_table_.get(i).get(0) + "[shape = doublecircle];";
                gViz.addln(out);
            }

        }

        for(int i = 0; i < length; i++)
        {
            int start = final_table_.get(i).get(0);
            for(int j = 1; j <= alphabeta_.size(); j++)
            {
                String out = new String();
                int end = final_table_.get(i).get(j);
                if(end != -1)
                {
                    out += start + "->" + end + " [label = ";
                    char c = ar_alphabeta_.get(j-1);
                    out += String.valueOf(c) + "];";
                    gViz.addln(out);
                }
            }
        }

        gViz.end_graph();
        try {
            gViz.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}




