package bianyi;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
public class first {
    public static void main(String[] args) {
        new frame().init();
    }
}
//a(ε|b|c)d(b|ε)
//a(a|b)*abba(a|b|c)*abb
//a*(a|b)abb
//dot dotcode.txt -T png -o 33.png
class tu {
    public int top;
    public int end;

    public tu(int top, int end) {
        this.top = top;
        this.end = end;
    }
}
class nfa implements Comparable<nfa>{
    public int top;
    public String guo;
    public int end;
    public nfa(){

    }

    public nfa(int top, String guo, int end) {
        this.top = top;
        this.guo = guo;
        this.end = end;
    }

    @Override
    public int compareTo(nfa o) {
        if (this.top==o.top)
            return this.end-o.end;

        return this.top-o.top;
    }

    @Override
    public String toString() {
        return "nfa{" +
                "top=" + top +
                ", guo='" + guo + '\'' +
                ", end=" + end +
                '}';
    }
}
class expression_minDFA{
    private ArrayList<Character> arrayList = new ArrayList();
    private Set<Character> setlist = new HashSet();
    private ArrayList<String> group = new ArrayList();
    private ArrayList<String> mingroup = new ArrayList();
    private int max;
    private int kk=0;


    public void total(Character a){
        if (a!='ε'&&setlist.add(a)){
            arrayList.add(a);
        }
    }

    public StringBuffer expression(String str){
        StringBuffer buffer = new StringBuffer();
        if (str!=null){
            Stack chars = new Stack();
            for (int i = 0; i < str.length()-1; i++) {//防止数组越界
                if (str.charAt(i)!=' '){//防止输入的是空格
                    buffer.append(str.charAt(i));
                    if(     check(str.charAt(i))==0&&check(str.charAt(i+1))==0||
                            check(str.charAt(i))==0&&str.charAt(i+1)=='('||
                            check(str.charAt(i+1))==0&&str.charAt(i)==')'||
                            str.charAt(i+1)=='('&&str.charAt(i)==')'||
                            check(str.charAt(i+1))==0&&str.charAt(i)=='*'||
                            str.charAt(i+1)=='('&&str.charAt(i)=='*'){
                        buffer.append('·');
                    }
                }
            }
            if(str.charAt(str.length()-1)!=' ')
                buffer.append(str.charAt(str.length()-1));
        }
        return buffer;
    }

    public StringBuffer reverse(StringBuffer str){
        Stack<Character> stack = new Stack();
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            if(check(str.charAt(i))==0){
                buffer.append(str.charAt(i));
            }
            else if(str.charAt(i)=='('){
                stack.push(str.charAt(i));
                //System.out.println("1:"+str.charAt(i)+"压栈");
            }
            else if(str.charAt(i)==')'){
                while (!(stack.peek() =='(')){
                    //System.out.println("2:"+stack.peek()+"出栈");
                    buffer.append(stack.pop());
                }
                //System.out.println("3:"+stack.peek()+"出栈");
                stack.pop();
            }
            else if(check(str.charAt(i))==1){
                if(stack.empty()||you(stack.peek(),str.charAt(i))||stack.peek()=='('){
                    stack.push(str.charAt(i));
                    //System.out.println("4:"+stack.peek()+"压栈");
                }
                else if(!you(stack.peek(),str.charAt(i))){
                    while (!stack.empty()&&!you(stack.peek(),str.charAt(i))){
                        if (stack.peek() =='(')
                            break;;
                        // System.out.println("5:"+str.charAt(i)+"   "+stack.peek()+"    "+stack.peek()+"出栈");
                        buffer.append(stack.pop());
                    }
                    stack.push(str.charAt(i));
                    // System.out.println("6:"+str.charAt(i)+"压栈");
                }
            }
            // System.out.println(buffer);
        }
        while (!stack.empty()){
            // System.out.println("666666"+stack.peek());
            buffer.append(stack.pop());
        }
        //System.out.println(buffer);
        return buffer;
    }

    public ArrayList NFA(StringBuffer str){
        draw draw = new draw("NFA",kk);
        draw.begin();
        int k=1;
        Stack<tu> tus = new Stack<>();
        int qian=0;
        int n=0;
        for (int i = 0; i < str.length(); i++) {
            if (check(str.charAt(i))==0){
                draw.increase(k++,""+str.charAt(i),k++);
                tus.push(new tu(k-2,k-1));
                qian=k-2;
                total(str.charAt(i));
            }
            else if(str.charAt(i)=='*'){
                tu tt=tus.pop();
                draw.increase(k++,"ε",tt.top);
                draw.increase(tt.end,"ε",k++);
                draw.increase((k-2),"ε",(k-1));
                draw.increase(tt.end,"ε",tt.top);
                tus.push(new tu(k-2,k-1));
                qian=k-2;
            }else if(str.charAt(i)=='|'){
                tu tt1=tus.pop();
                tu tt2=tus.pop();
                draw.increase(k,"ε",tt1.top);
                draw.increase(k++,"ε",tt2.top);
                draw.increase(tt1.end,"ε",k);
                draw.increase(tt2.end,"ε",k++);
                tus.push(new tu(k-2,k-1));
                qian=k-2;
            }else if (str.charAt(i)=='·'){
                tu tt1=tus.pop();
                tu tt2=tus.pop();
                draw.increase(tt2.end,"ε",tt1.top);
                tus.push(new tu(tt2.top,tt1.end));
                qian=tt2.top;
            }
        }
        draw.increase(0,"ε",qian);
        max=k-1;
        draw.set(new String(""+(k-1)));
        draw.end();
        return draw.back();
    }

    public ArrayList<String[]> DFA(ArrayList<nfa> list){
        Collections.sort(list);
        ArrayList<String[]> aLists = new ArrayList();
        ArrayList<Integer> ints = new ArrayList();//相当于一个数组
        ints.add(list.get(0).end);
        //System.out.println(list.get(0).end);
        //因为我加了一个起始点0，因为排序了，所以0就是我想找的起始点，只需要知道起始点连接的第一个点
        ArrayList<ArrayList<Integer> > ls = new ArrayList();//相当于存放很多的数组，就像DFA最左边的那一竖
        Set<ArrayList<Integer> > ss = new HashSet();
        ints=epsilion(ints,"ε",list,0);//为了寻找真正起始点所有的空连接的点
        //System.out.println(ints);
        //if (ints.size()==0)
        ints.add(list.get(0).end);
        ls.add(ints);
        ss.add(ints);
        for (int i = 0; i < ls.size(); i++) {
            String[] strings = new String[arrayList.size()+1];
            if (ls.get(i).contains(max))
                group.add("1");
            else
                group.add("0");
            strings[0]=ls.get(i).toString();
            //System.out.print("\n第"+i+":"+strings[0]+" \n");
            for (int i1 = 0; i1 < this.arrayList.size(); i1++) {//aarrayList存储的是所有的符号，比如a,b,c;

                ints=epsilion2(ls.get(i),""+ this.arrayList.get(i1),list,0);
                //开始以起始点去找所有的点，这个函数就是把一个数组里每一个数只通过一个符号能走到的所有数返回回来，
                // 可以是1走2,2走3，就返回2,3

//                for (int i2 = 0; i2 < ints.size(); i2++) {
//                    System.out.print(ints.get(i2)+" ");
//                }
//                System.out.println("\nkong");
                ints.addAll(epsilion(ints,"ε",list,0));
//                for (int i2 = 0; i2 < ints.size(); i2++) {
//                    System.out.print(ints.get(i2)+" ");
//                }
                //找空的
                ints.sort(new Comparator<Integer>() {
                    @Override
                    public int compare(Integer o1, Integer o2) {
                        return o1-o2;//升序
                    }});
                strings[i1+1]=ints.toString();//将数组都变成字符串

                if(!ints.isEmpty()&&!ss.contains(ints)){
                    ss.add(ints);
                    ls.add(ints);
                }
            }
            System.out.println("");
            aLists.add(strings);
        }
//        for (int i = 0; i < aLists.size(); i++) {
//            for (int i1 = 0; i1 < arrayList.size() + 1; i1++) {
//                System.out.print(aLists.get(i)[i1]+" ");
//            }
//            System.out.println("");
//        }

        for (int l = 0; l < aLists.size(); l++) {
            for (int i1 = 1; i1 <= arrayList.size(); i1++) {
                for (int i = 0; i < aLists.size(); i++) {
                    if (aLists.get(l)[i1].equals(aLists.get(i)[0])){
                        aLists.get(l)[i1]=""+(i+1);
                        break;
                    }
                }
            }
        }//改名字
        for (int l = 0; l < aLists.size(); l++){
            aLists.get(l)[0]=""+(l+1);
        }
        return aLists;
    }

    public ArrayList<Integer> epsilion(ArrayList<Integer> aa,String b,ArrayList<nfa> list,int c){
        if (aa.isEmpty())
            return aa;
        Set<Integer> set= new HashSet();
        ArrayList<Integer> list1 = new ArrayList<>();
        Queue<Integer> queue2 = new LinkedList<>();
        int k=0;
        for (int l = 0; l < aa.size(); l++) {
            if (set.contains(aa.get(l)))
                continue;
            k=list1.size();//因为循环类是把一个数字出发经过符号可以到的所有都加到里面，为了减少运算量

            list1.add(aa.get(l));//先加入为了开启循环后面再删掉
            for (int i = k; i < list1.size(); i++) {
                queue2=check(list1.get(i),b,list);//这个函数就是把一个数只通过一次符号找到的返回
                while (queue2.size()!=0){
                    if (set.add(queue2.peek())){
                        list1.add(queue2.poll());
                    }else
                        queue2.poll();
                }
            }
            list1.remove(aa.get(l));
        }
//        for (int i = 0; i < list1.size(); i++) {
//            if (!set.contains(list1.get(i))){
//                list1.remove(list1.get(i));//记住默认是元素，然后才是索引
//            }
//        }
        list1.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1-o2;//升序
            }
        });
        return list1;
    }

    public ArrayList<Integer> epsilion2(ArrayList<Integer> aa,String b,ArrayList<nfa> list,int c){
        if (aa.size()==0)
            return aa;
        Set<Integer> set= new HashSet();
        ArrayList<Integer> list1 = new ArrayList<>();
        Queue<Integer> queue2 = new LinkedList<>();
        int k=0;
        for (int l = 0; l < aa.size(); l++) {

            queue2=check(aa.get(l),b,list);//这个函数就是把一个数只通过一次符号找到的返回
            while (queue2.size()!=0){
                if (set.add(queue2.peek())){
                    list1.add(queue2.poll());
                }else
                    queue2.poll();
            }

        }

        list1.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1-o2;//升序
            }
        });
        return list1;
    }

    public ArrayList<String> minDFA(ArrayList<String[]> aa){
        String ff=new String();
        ArrayList<String> group2 = new ArrayList();
        for (int i = 0; i < aa.size(); i++) {
            if (group.get(i).equals(group.get(0)))
                group2.add(""+0);
            else
                group2.add(""+1);
        }
        int ee=0;//分类的数字，最大表示分了几类
        int k=2;//表示上一步最大的类个数
        while (true){
            ee=0;
            ArrayList<String> bb = new ArrayList();

            //这是把一行的字符串加在一起方便比较
            for (int i = 0; i < aa.size(); i++) {
                ff=group2.get(i);
                for (int i1 = 1; i1 <= arrayList.size(); i1++) {
                    ff+=" ";
                    if (aa.get(i)[i1].equals("[]")){
                        ff+="#";
                    }else{
                        ff+=group2.get(Integer.parseInt(aa.get(i)[i1])-1);
                    }
                }
                bb.add(ff);
            }
            //开始比较，进行等价运算
            for (int i = 0; i < aa.size(); i++) {
                int s=bb.indexOf(bb.get(i));
                if (i>s){
                    group2.set(i,group2.get(s));//修改                  的风格的规定发给对方犯规
                }else {
                    group2.set(i,""+(ee++));
                }
            }
            if (ee==k){
                int uu=0;
                for (int i = 0; i < bb.size(); i++) {
                    int s=bb.indexOf(bb.get(i));
                    if (i>s){
                        bb.remove(i);//记住删除是删除出现的第一个
                        i--;
                        uu++;
                    }
                    else {

                        mingroup.add(group.get(uu+i));//因为i减了，所以要找到正确的定位
                    }
                }
                return bb;
            }
            else
                k=ee;
        }
    }

    public ArrayList<int[]> transform(ArrayList<String> aa){
        ArrayList<int[]> ints = new ArrayList<>();
        StringBuffer buffer = new StringBuffer();
        int k=0;
        int[] int1 ;

        //是要将一行字符串转变成数组
        for (int i = 0; i < aa.size(); i++) {
            k=0;
            int1 = new int[arrayList.size()+1];
            for (int i1 = 0; i1 < aa.get(i).length(); i1++) {
                char bb=aa.get(i).charAt(i1);
                if(bb!=' '&&bb!='#'){
                    buffer.append(bb);
                }
                else if(bb=='#'){
                    int1[k++]=-1;
                }
                else if (buffer.length()>0){
                    int1[k++]=Integer.parseInt(String.valueOf(buffer))+1;
                    buffer.delete(0, buffer.length());
                }
            }
            if (buffer.length()>0){
                int1[k]=Integer.parseInt(String.valueOf(buffer))+1;
                buffer.delete(0, buffer.length());
            }
//            for (int i1 = 0; i1 < int1.length; i1++) {
//                System.out.print(int1[i1]+" ");
//            }
//            System.out.println("");
            ints.add(int1);//相当于放的是数组的地址
        }

//            for (int l = 0; l < ints.size(); l++) {
//                for (int i1 = 0; i1 < arrayList.size() + 1; i1++) {
//                    System.out.print(ints.get(l)[i1]+" ");
//                }
//                System.out.println("");
//            }
        return ints;
    }

    public void draww(ArrayList<int[]> aa){
        String AA="minDFA";
        draw draw = new draw(AA,kk);
        draw.begin();
        int qian=1;
        for (int i = 0; i < aa.size(); i++) {
            for (int i1 = 1; i1 <= arrayList.size(); i1++) {
                int a=aa.get(i)[0];
                int b=aa.get(i)[i1];
                if (b>0){
                    draw.increase(a,""+arrayList.get(i1-1),b);
                    if (b==qian)
                        qian=a;
                }

            }
        }
        draw.increase(0,"ε",qian);
        for (int i = 0; i < mingroup.size(); i++) {
            if (mingroup.get(i).equals("1"))
                draw.set(String.valueOf(aa.get(i)[0]));
        }
        draw.end();

    }

    public Queue check(int a,String b,ArrayList<nfa> list){
        boolean xu=false;
        Queue<Integer> queue =  new LinkedList();
        for (int i = a; i < list.size(); i++) {
            if (list.get(i).top==a&&list.get(i).guo.equals(b)){
                queue.offer(list.get(i).end);
                xu=true;
            }
            else if (xu){
                break;
            }
        }
        return queue;

    }

    public int check(char a){
        if(a=='|'||a=='*'||a=='·')
            return 1;
        else if(a=='('||a==')')
            return 2;
        else if (a==' ')
            return 3;

        return 0;
    }

    public static boolean you(char a,char b){
        ArrayList list = new ArrayList();
        list.add('|');
        list.add('·');
        list.add('*');
        if(list.indexOf(a)<list.indexOf(b))
            return true;
        else
            return false;


    }

    public ArrayList<Character> back(){
        return arrayList;
    }

    public ArrayList<String> mingroup(){
        return mingroup;
    }

    public ArrayList<String> group(){
        return group;
    }

    public void setted(int a){
        kk=a;
    }
}

class frame{
    public String content=new String();
    public String check=new String();
    public expression_minDFA app;//
    public StringBuffer a;
    public StringBuffer b;
    public ArrayList c;
    public ArrayList<String[]> d;
    public ArrayList<String> e;
    public ArrayList<int[]> f;

    public ArrayList<Character> fuhao;
    public ArrayList<String> mingroup;
    public ArrayList<String> group;

    public JLabel jLabelresult = new JLabel();
    public JPanel jPanelresult = new JPanel();
    public JFrame jFrame = new JFrame();
    public JScrollPane jScrollPane = new JScrollPane();

    private int kk=0;

    public String run(){
        app=new expression_minDFA();
        if (content.length()>0&&!check.equals(content)){
            try {
                app.setted(kk);
                a=app.expression(content);
                b=app.reverse(a);
                c=app.NFA(b);
                d=app.DFA(c);
                e=app.minDFA(d);
                f=app.transform(e);
                app.draww(f);
                fuhao=app.back();
                group=app.group();
                mingroup=app.mingroup();
                check=content;
                kk++;
                return "运行成功第"+kk+"次";
            } catch (Exception e) {
                return "请输入正确的正则表达式";
            }
        }
        else if (content.length()==0)
            return "数据为空";

        return "请勿重复点击";
    }

    public JFrame init(){
        jFrame.setBounds(70,200,1800,600);
        jFrame.setLayout(new BorderLayout());
        JPanel jPanel1 = top();
        JPanel jPanel2 =center();
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(2,1,10,10));
        jPanel.add(jPanel1);
        jPanel.add(jPanel2);
        jFrame.add(jPanel,BorderLayout.NORTH);
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //jFrame.setResizable(false);
        jFrame.setVisible(true);
        return jFrame;
    }

    public JPanel center(){
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());
        JPanel jPanel1 =new JPanel();
        JButton jButton1 = new JButton();
        JButton jButton2 = new JButton();
        JButton jButton3 = new JButton();
        JButton jButton4 = new JButton();
        JButton jButton5 = new JButton();
        JButton jButton6 = new JButton();
        jButton1.setFont(new Font("宋体",Font.BOLD,15));
        jButton1.setText("完整表达式");
        jButton2.setFont(new Font("宋体",Font.BOLD,15));
        jButton2.setText("逆波兰表达式");
        jButton3.setFont(new Font("宋体",Font.BOLD,15));
        jButton3.setText("NFA图片");
        jButton4.setFont(new Font("宋体",Font.BOLD,15));
        jButton4.setText("DFA表格");
        jButton5.setFont(new Font("宋体",Font.BOLD,15));
        jButton5.setText("最小DFA表格");
        jButton6.setFont(new Font("宋体",Font.BOLD,15));
        jButton6.setText("最小DFA图");
        jPanel1.add(jButton1);
        jPanel1.add(jButton2);
        jPanel1.add(jButton3);
        jPanel1.add(jButton4);
        jPanel1.add(jButton5);
        jPanel1.add(jButton6);
        action action = new action();
        jButton1.addActionListener(action);
        jButton2.addActionListener(action);
        jButton3.addActionListener(action);
        jButton4.addActionListener(action);
        jButton5.addActionListener(action);
        jButton6.addActionListener(action);
        jPanel.add(jPanel1,BorderLayout.NORTH);
        return jPanel;
    }

    public JPanel top(){
        JPanel jPanel = new JPanel();
        JTextField jTextField = new JTextField();
        jTextField.setColumns(40);
        jLabelresult.setFont(new Font("宋体",Font.BOLD,12));
        jLabelresult.repaint();
        jTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JTextField jTextField= (JTextField) e.getSource();
                content=jTextField.getText();
                jLabelresult.setText(run());
            }
        });

        JLabel jLabel = new JLabel();
        jLabel.setFont(new Font("宋体",Font.BOLD,20));
        jLabel.setText("请输入正则表达式:");
        jPanel.add(jLabel);
        jPanel.add(jTextField);
        jPanel.add(jLabelresult);
        return jPanel;
    }

    public JPanel incentter(String aa){
        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BorderLayout());
        // jPanel.setPreferredSize(new Dimension(1700,400));
        if (aa.equals("完整表达式")){
            JTextField jTextField = new JTextField();
            jTextField.setFont(new Font("宋体",Font.BOLD,30));
            jTextField.setText(new String(a));
            jPanel.add(jTextField,BorderLayout.CENTER);
        }
        else if (aa.equals("逆波兰表达式")){
            JTextField jTextField = new JTextField();
            jTextField.setFont(new Font("宋体",Font.BOLD,30));
            jTextField.setText(new String(b));
            jPanel.add(jTextField,BorderLayout.CENTER);
        }
        else if (aa.equals("NFA图片")){
            //JLabel jLabel1 = new JLabel();
            //jLabel1.setFont(new Font("宋体",Font.BOLD,20));
            // jLabel1.setText("0指向的是表达式的起始点");
            String s = new String("D:/IDE/javacode/schoolJava/src/bianyi/drawing/NFA" + (kk - 1) + ".png");
            ImageIcon icon = new ImageIcon(s);//这个一个图片标签
            JLabel jLabel = new JLabel(icon, SwingConstants.CENTER);//swing是居中
//            JTextArea jTextArea = new JTextArea();
//            jTextArea.add(jLabel);
            //icon.setImage(icon.getImage().getScaledInstance(1700, 300,Image.SCALE_DEFAULT ));
            //jPanel.add(jLabel1,BorderLayout.NORTH);
            jPanel.add(jLabel,BorderLayout.CENTER);
        }
        else  if (aa.equals("DFA表格")){
            JLabel jLabel = new JLabel();
            jLabel.setFont(new Font("宋体",Font.BOLD,20));
            jLabel.setText("[]表示无法到达");
            JTextArea jTextArea = new JTextArea();
            jTextArea.setFont(new Font("宋体",Font.BOLD,20));
            jTextArea.append(String.format("%-10s", "S"));
            for (int i = 0; i < fuhao.size(); i++) {
                jTextArea.append(String.format("%-10s", fuhao.get(i)));
            }
            jTextArea.append(String.format("%-10s", "状态(1表示终止点)"));
            jTextArea.append("\n");
            for (int i = 0; i < d.size(); i++) {
                for (int i1 = 0; i1 <= fuhao.size(); i1++) {
                    jTextArea.append(String.format("%-10s", d.get(i)[i1]));
                }
                jTextArea.append(String.format("%-10s", group.get(i)));
                jTextArea.append("\n");
            }
            jPanel.add(jLabel,BorderLayout.NORTH);
            jPanel.add(jTextArea,BorderLayout.CENTER);

        }
        else  if (aa.equals("最小DFA表格")){
            JLabel jLabel = new JLabel();
            jLabel.setFont(new Font("宋体",Font.BOLD,20));
            jLabel.setText("-1表示无法到达");
            JTextArea jTextArea = new JTextArea();
            jTextArea.setFont(new Font("宋体",Font.BOLD,20));
            jTextArea.append(String.format("%-10s", "S"));
            for (int i = 0; i < fuhao.size(); i++) {
                jTextArea.append(String.format("%-10s", fuhao.get(i)));
            }
            jTextArea.append(String.format("%-10s", "状态(1表示终止点)"));
            jTextArea.append("\n");
            for (int i = 0; i < f.size(); i++) {
                for (int i1 = 0; i1 <= fuhao.size(); i1++) {
                    jTextArea.append(String.format("%-10s",f.get(i)[i1]));
                }

                jTextArea.append(String.format("%-10s", mingroup.get(i)));
                jTextArea.append("\n");
            }
            jPanel.add(jLabel,BorderLayout.NORTH);
            jPanel.add(jTextArea,BorderLayout.CENTER);

        }
        else if (aa.equals("最小DFA图")){
            JLabel jLabel1 = new JLabel();
            jLabel1.setFont(new Font("宋体",Font.BOLD,20));
            // jLabel1.setText("0指向的是表达式的起始点");
            String s = new String("D:/IDE/javacode/schoolJava/src/bianyi/drawing/minDFA" + (kk - 1) + ".png");
            ImageIcon icon = new ImageIcon(s);//这个一个图片标签
            JLabel jLabel = new JLabel(icon, SwingConstants.CENTER);
            jLabel.setIcon(icon);
            jPanel.add(jLabel1,BorderLayout.NORTH);
            jPanel.add(jLabel,BorderLayout.CENTER);
        }
        return jPanel;
    }

    class action implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton a= (JButton) e.getSource();
            if (jPanelresult.getComponentCount()==1){
                jPanelresult.remove(0);
                jPanelresult.updateUI();
            }
            //jPanelresult.setPreferredSize(new Dimension(1500,300));
            jPanelresult.add(incentter(a.getActionCommand()),BorderLayout.CENTER);
            jScrollPane.setViewportView(jPanelresult);
            jFrame.add(jScrollPane,BorderLayout.CENTER);
            jFrame.setVisible(true);

        }
    }

}



