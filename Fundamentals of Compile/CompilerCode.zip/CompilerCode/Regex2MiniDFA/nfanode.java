package Regular_Expression;

/**
 * 仅在生成NFA过程中使用的
 * 是需要压入栈的自定义类型
 * 记录以及对某个运算符运算结束但未并入整个NFA的节点
 * 例如 ab. 运算结束后 nfanode仅存储5，6
 * 内包含的5-*->1-a->2-*->3-b->4-*->6关系存储在node中
 */

public class nfanode
{

    int src; // 起始节点
    int dst; // 终止节点

    nfanode()
    {

    }
    nfanode(int a, int b)
    {
        src = a;
        dst = b;

    }

    public void set(int a, int b)
    {
        this.src = a;
        this.dst = b;
    }


}
