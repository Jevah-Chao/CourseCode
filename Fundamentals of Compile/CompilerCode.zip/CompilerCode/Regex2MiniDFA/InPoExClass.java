package Regular_Expression;

/**
 * 将逆波兰表达式生成过程封装成类
 * 传入一个String 即要处理的后缀表达式
 */

import java.util.*;

public class InPoExClass
{
    public StringBuffer inputString = new StringBuffer();
    public String outString = new String();
    public Set<Character> alphabeta_ = new HashSet();

    private static Map map;
    static {
        Map<Character , Integer> pre_map = new HashMap<Character, Integer>();

        pre_map.put('*', 1);// 最高优先级
        pre_map.put('.', 2);
        pre_map.put('|', 3);
        pre_map.put('(', 1000);
    }

    InPoExClass()
    {

    }

    InPoExClass(String a)
    {
        inputString.append(a);
    }

    public Set<Character> Get_alphabeta_()
    {
        return this.alphabeta_;
    }

    public int check(char a)
    {
        if(a=='|'||a=='*'||a=='·')
            return 1;
        else if(a=='('||a==')')
            return 2;
        else if (a==' ')
            return 3;

        return 0;
    }

    /**
     *
     * @param get：InPoExclass类类型后缀表达式
     * @return：返回String类型逆波兰表达式
     */
    public void Get_InPoExpression(InPoExClass get)
    {
        StringBuffer buffer = new StringBuffer();
        if (inputString!=null)
        {
            Stack chars = new Stack();
            for (int i = 0; i < inputString.length()-1; i++)
            {//防止数组越界
                if (inputString.charAt(i)!=' ')
                {//防止输入的是空格
                    buffer.append(inputString.charAt(i));
                    if(     check(inputString.charAt(i))==0&&check(inputString.charAt(i+1))==0||
                            check(inputString.charAt(i))==0&&inputString.charAt(i+1)=='('||
                            check(inputString.charAt(i+1))==0&&inputString.charAt(i)==')'||
                            inputString.charAt(i+1)=='('&&inputString.charAt(i)==')'||
                            check(inputString.charAt(i+1))==0&&inputString.charAt(i)=='*'||
                            inputString.charAt(i+1)=='('&&inputString.charAt(i)=='*')
                    {
                        buffer.append('.');
                    }
                }
            }
            if(inputString.charAt(inputString.length()-1)!=' ')
                buffer.append(inputString.charAt(inputString.length()-1));
        }
        inputString = buffer;





        //定义优先级map
        Map<Character , Integer> pre_map = new HashMap<Character, Integer>();

        pre_map.put('*', 1);// 最高优先级
        pre_map.put('.', 2);
        pre_map.put('|', 3);
        pre_map.put('(', 1000);

        //Scanner scanner = new Scanner(System.in);
        //String input = scanner.next();

        //InPoExClass get = new InPoExClass(input);

        System.out.println("InPoExClass inputString = " + get.inputString);

        int length = get.inputString.length();

        Stack<Character> operator = new Stack<Character>();

        char[] a = new  char[1000];

        get.inputString.getChars(0, length, a, 0);


        for(Integer i = 0; i < length; i++)
        {
            if(a[i] >= 'A' && a[i] <= 'z')
            {
                get.outString += a[i];
                get.alphabeta_.add(a[i]);
            }

            else
            {
                if(operator.empty())
                {
                    operator.push(a[i]);
                }
                else
                {
                    switch (a[i])
                    {
                        case '*':
                        {
                            while (operator.peek() == '*')
                            {
                                get.outString += operator.peek();
                                operator.pop();
                                if(operator.empty())
                                    break;
                            }
                            operator.add(a[i]);
                            break;

                        }
                        case '.':
                        {
                            while (pre_map.get(operator.peek()) <= 2 )
                            {
                                get.outString += operator.peek();
                                operator.pop();
                                if(operator.empty())
                                    break;
                            }
                            operator.add(a[i]);
                            break;
                        }
                        case '|':
                        {

                            while (pre_map.get(operator.peek()) <= 3)
                            {
                                get.outString += operator.peek();
                                operator.pop();
                                if(operator.empty())
                                    break;
                            }
                            operator.add(a[i]);
                            break;
                        }
                        case'(':
                        {
                            operator.add('(');
                            break;
                        }
                        case ')':
                        {
                            while (operator.peek() != '(')
                            {
                                get.outString += operator.peek();
                                operator.pop();
                            }
                            operator.pop();
                            break;
                        }

                        default:
                            System.out.println("defult");
                    }
                }
            }



        }
        System.out.println("InPOExClass alphabeta: "+alphabeta_);
        while(!operator.empty())
        {
            get.outString += operator.peek();
            operator.pop();
        }

//        System.out.println("Inpoexclass: "+get.Get_alphabeta_());


    }



}
