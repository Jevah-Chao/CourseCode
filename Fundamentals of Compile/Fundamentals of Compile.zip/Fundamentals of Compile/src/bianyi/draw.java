package bianyi;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class draw {

    GraphViz gViz=new GraphViz("D:\\Graphviz\\drawing", "D:\\Graphviz\\bin\\dot.exe");
    ArrayList<nfa> list = new ArrayList<>();

    public void begin(){
        gViz.start_graph();

    }
    public static void main(String[] args) {
    }
    public draw(){}

    public draw(String ss,int a){
        gViz.sett(ss,a);
    }
    public void set(String a){
        gViz.addend(a);
    }
    public void increase(int a,String b,int c){
        if (a!=0)
            gViz.add(new String(""+a+"->"+""+c),b);
        else
            gViz.setbegin(""+c);
        list.add(new nfa(a,b,c));

    }
    public void end(){
        gViz.end_graph();
        try {
            gViz.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public ArrayList back(){
        return list;
    }
}

class  GraphViz{
    private String txtPath = "";
    private String dotPath = "";
    private String runOrder="";
    private String dotCodeFile="dotcode.txt";
    private String resultGif="dotPNG";
    private StringBuilder graph = new StringBuilder();
    private int kk=0;

    Runtime runtime=Runtime.getRuntime();
    public void sett(String aa,int a){
        dotCodeFile=aa+a+".txt";
        resultGif=aa+a;
    }

    public void run() {
        writeGraphToFile(graph.toString(), txtPath);
        creatOrder();
        try {
            runtime.exec(runOrder);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void creatOrder(){
        runOrder+=dotPath+" ";
        runOrder+=txtPath;
        runOrder+=dotCodeFile+" ";
        runOrder+="-T png ";
        runOrder+="-o ";
        runOrder+=txtPath;
        runOrder+=resultGif+".png";
        //System.out.println(runOrder);
    }

    public void writeGraphToFile(String dotcode, String filename) {
        try {

            File file = new File(filename+dotCodeFile);

            if(!file.exists()){
                file.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(dotcode.getBytes());
            fos.close();
        } catch (Exception ioe) {
            ioe.printStackTrace();
        }
    }

    public GraphViz(String txtPath,String dotPath) {
        this.txtPath=txtPath;
        this.dotPath=dotPath;
    }

    public void add(String line) {
        graph.append("\t"+line+";\n");
    }
    public void setbegin(String a){graph.append("\t\"\"[shape=none];\n\t\"\"->"+a+";\n");}

    public void add(String line,String guo) {
        graph.append("\t"+line + "[label="+guo+"];\n");
    }
    public void addend(String line) {
        graph.append("\t"+line + "[peripheries=2];\n");
    }

    public void start_graph() {
        graph.append("digraph G {\n\trankdir = LR\n") ;
    }

    public void end_graph() {
        graph.append("}") ;
    }
}
//