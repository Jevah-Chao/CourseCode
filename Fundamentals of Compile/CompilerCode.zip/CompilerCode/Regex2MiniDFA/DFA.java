package Regular_Expression;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Collections;
import java.util.stream.Collector;


public class DFA extends NFA
{
    public Set<Character> alphabeta_ = new HashSet();
    public int headnode;
    public node[] dfa_ = new node[100];
    public int nodenum_;
    
    

    DFA()
    {
        //alphabeta_ = super.Get_alphabeta_();
    }

    public Set<Character> Get_alphabeta_()
    {
        return this.alphabeta_;
    }


    /**
     * 绘制DFA的函数
     * @param length: 节点个数
     */
    public void Drawgraph(int length)
    {

        GraphVizTest gViz=new GraphVizTest("D:\\Graphviz\\DFA", "D:\\Graphviz\\bin\\dot.exe");

        gViz.start_graph();
        gViz.addln("graph [rankdir=LR];");

        for(int i = 1; i <= length; i++)
        {
            String out = new String();
            if(this.dfa_[i].isEnd)
            {
                out += this.dfa_[i].current + "[shape = doublecircle];";
                gViz.addln(out);
            }

        }

        for(int i = 1; i <= length; i++)
        {

            for(int k = 0; k < this.dfa_[i].next.size(); k++)//k记录每个node有多少个next
            {
                String out = new String();
                out += this.dfa_[i].current + "->" + this.dfa_[i].next.get(k)+ " [label = ";

                char c = this.dfa_[i].way.charAt(k);
                if(c != '*')
                    out += String.valueOf(c);
                else
                    out += "ε";

                out += "];";
                gViz.addln(out);
            }
        }

        gViz.end_graph();
        try {
            gViz.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 将新状态Set转换成arrayList类型
     */
    public void Transform_State_Set_to_array(Set<Integer> new_state, ArrayList<Integer> ar_new_state)
    {
        ar_new_state.clear();
        for(Integer Int : new_state)
        {
            ar_new_state.add(Int);
        }
        new_state.clear();
        /*

         */
        //System.out.println("DFA transform set to arrlist: " + ar_new_state);
    }


    /**
     * 从NFA生成DFA的 node（新状态及转换关系）
     * @param Node
     */
    public void draw_dfa(node[] Node)
    {
//        NFA draw_nfa = new NFA();
//        node[] Node = draw_nfa.resNfa();
//        this.headnode = draw_nfa.headnode;
//        this.alphabeta_ = draw_nfa.alphabeta_;
//
//        System.out.println("nfa headnode = " + this.headnode);
//        System.out.println("DFA alphabeta_： " + this.alphabeta_);


        /**
         * 初始化记录DFA的node
         */
        for(int i = 1; i < 100; i++)
        {
            this.dfa_[i] = new node(i);
        }

        int start = this.headnode; //  NFA的起始节点
        int end = start + 1; // NFA的终止节点
        HashSet<Integer> new_state = new HashSet(); // 仅保存一个状态 新的状态，使用set去除重复点，其中包含的是start可以通过*到达的节点
        Iterator<Integer> state_it = new_state.iterator();// 未使用
        Iterator<Character> ab_it = this.alphabeta_.iterator();// 未使用

        ArrayList<ArrayList<Integer>> all_state = new ArrayList<>(); //保存所有状态 生成DFA时使用
        int all_stateCount = 0; // 记录状态数  值等于all_state_set.size()
        Set<ArrayList<Integer>> all_state_set = new HashSet<ArrayList<Integer>>() ;//保存所有状态 辅助all_state的生成

        /**
         * 从起始节点获取第一个新的DFA状态 即从start通过空转换可以到达的节点
         * 并输出
         */
        this.Get_New_State(start, new_state, Node, '*');
        System.out.println("DFA start new_state = " + new_state);

        /**
         * 将第一个状态转换为array list
         */
        ArrayList<Integer> ar_new_state = new ArrayList<>();
        Transform_State_Set_to_array(new_state, ar_new_state);
        Collections.sort(ar_new_state);

        all_state.add(ar_new_state);// 将
        all_stateCount++;
        all_state_set.add(ar_new_state);

        /**
         * 将字母表set转换为array list
         * 并输出
         */
        ArrayList<Character> ar_alphabeta = new ArrayList<Character>();
        for(Character Char : this.alphabeta_)
        {
            ar_alphabeta.add(Char);
        }
        System.out.println("array list字母表" + ar_alphabeta);
        


        /**
         * 遍历每个新状态经过不同方法能够到达的状态
         */
        for(int k = 0; k < all_state_set.size(); k++)// 遍历所有状态
        {
            //turn_of_dfa++;
            // 一个起始状态 所有方法 可以到的状态
            for (int j = 0; j < ar_alphabeta.size(); j++)// 遍历所有方法 即字母表
            {
                ar_new_state = all_state.get(k);// 起始状态 从allstate中逐个取 第一层for循环控制
                /*

                 */
                //System.out.println("ar_new_state " + ar_new_state);

                // 一起始状态 一方法 可以到的所有节点
                for (int i = 0; i < ar_new_state.size(); i++)// 遍历每个状态中所有节点
                {
                    Integer a = ar_new_state.get(i); // 从当前状态逐个取节点
                    Character b = ar_alphabeta.get(j);// 当前 一个 方法
                    /*

                     */
                    //System.out.println("DFA start way: " + a + b);
                    Get_New_State(a, new_state, Node, b);// a节点经过b方法和空转换可以到的新节点
                }

                // 输出 当前状态所有节点 经过当前方法 可到达到的 新状态
                /*

                 */
                //System.out.println(j + ar_alphabeta.get(j) + " DFA new_state = " + new_state);

                /**
                 * 将新的状态保存在 all_state 中
                 */
                ArrayList<Integer> temp = new ArrayList<>(); // 将 new_state(set类型) 转换为 arraylist
                Transform_State_Set_to_array(new_state, temp);
                //如果新状态不为空
                if (temp.size() != 0)
                {
                    Collections.sort(temp);// 按数字大小排序

                    boolean a =  all_state_set.add(temp);// a 记录了当前新状态是否成功加入set 即是否是之前未出现的新状态
                    if(a) // 如果是
                    {
                        all_stateCount++;
                        all_state.add(temp); // 存入all_state的array list中
                    }
                }
                /*******************************************************************************************/
                /**
                 * 生成DFA node[] 即DFA关系
                 * 一个状态 搜索完 一个方法后 即可添加
                 */
                int cur, next;// 起始节点 下一节点

                if(!ar_new_state.isEmpty() && !temp.isEmpty())// 如果起始状态和下一状态都不为空
                {


                    cur = all_state.indexOf(ar_new_state) + 1;//cur =  返回 all_state中 起始状态的位置 相当于给新状态标号
                    next = all_state.indexOf(temp) + 1;//next =  返回 all_state中 下一状态的位置
                    /*
                    *//*
                    **************************
                     */
                    //System.out.println("cur = "+ cur + " next = " + next);// 输出起始DFA节点号和下一DFA节点号
                    if(ar_new_state.contains(end))
                        this.dfa_[cur].isEnd = true;
                    if (temp.contains(end))
                        this.dfa_[next].isEnd = true;
                    this.dfa_[cur].next.add(next);// 增加下一DFA节点
                    this.dfa_[cur].way.append(ar_alphabeta.get(j));// 增加到达方法
                }

                /*******************************************************************************************/
            }

        }
        System.out.println( "All New State Contain：" +all_state);
        System.out.println("all_state.size() = " + all_state.size());

        //绘制DFA
        nodenum_ = all_state_set.size();
        Drawgraph(all_state_set.size());
    }


    /**
     * 深度优先搜索
     * @param start：起始节点
     * @param new_state：保存新增加的NFA节点
     * @param Node：NFA的node关系
     * @param way：经历什么方法
     */
    public void Get_New_State(Integer start, Set new_state, node[] Node, char way)
    {
        if(way == '*')// 进入此条件的两种情况 1是找第一个DFA状态 2是其他DFA状态增加新的节点查找空转换能到的节点
            //1情况必须将起始节点加入新状态
            //2情况 走这个条件之前 已经过 非*方法 到达start 所以该语句无效
        {
            new_state.add(Node[start].current);// start = current 即 将自己加入新状态中
        }
        // way是不是*时都要走这个循环
        for(int i = 0; i < Node[start].way.length(); i++)// 遍历nfa 中 start 的 后继节点的途径方法
        {
 /*1*/           if(Node[start].way.charAt(i) == way)// 如果当前方法时way
 /*2*/           {
 /*3*/               boolean flag =  new_state.add(Node[start].next.get(i));// 将对应的NFA节点加入新状态
 /*4*/               if(flag)  // 如果是未搜索过的节点 搜索它 否则不用再搜一遍 不然回死循环 ！！！第一次没有加 出现死循环
                    {
                        Get_New_State(Node[start].next.get(i), new_state, Node, '*');// 然后查找它经过空转换能到达的节点
                    }
                }
        }
        return;
    }


}
