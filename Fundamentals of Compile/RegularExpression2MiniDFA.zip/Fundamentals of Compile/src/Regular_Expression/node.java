package Regular_Expression;

import java.util.ArrayList;

/**
 * 在 NFA DFA MiniDFA类中均使用
 * 记录已经生成的NFA
 * 即已经运算完成的节点之间的关系
 * DFA生成时也要使用
 */

public class node
{
    // 当前节点
    public int current;
    // 后继节点
    public ArrayList<Integer> next = new ArrayList<Integer>();
    boolean isEnd = false;

    // 方式
    public StringBuffer way = new StringBuffer();

    node(int count)
    {
        current = count;
    }


    node()
    {}


}
