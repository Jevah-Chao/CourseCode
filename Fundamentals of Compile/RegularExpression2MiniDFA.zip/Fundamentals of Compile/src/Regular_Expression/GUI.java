package Regular_Expression;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GUI extends MiniDFA
{
    public boolean flag_ = true;
    public static void main(String[] args)
    {

//        NFA NFA_Class = new NFA();
//        DFA DFA_Class = new DFA();
//        MiniDFA Mini_DFA_Class = new MiniDFA();
//
//        String input = JOptionPane.showInputDialog("请输入正则表达式");
//        InPoExClass InPoEx_Class = new InPoExClass(input);
//        InPoEx_Class.Get_InPoExpression(InPoEx_Class);
//
//        node[] Node = NFA_Class.resNfa(InPoEx_Class);
//
//        DFA_Class.headnode = NFA_Class.headnode;
//        DFA_Class.alphabeta_ = NFA_Class.alphabeta_;
//        System.out.println("nfa headnode = " + DFA_Class.headnode);
//        System.out.println("DFA alphabeta_： " + DFA_Class.alphabeta_);
//
//        DFA_Class.draw_dfa(Node);
//
//        Mini_DFA_Class.alphabeta_ = DFA_Class.alphabeta_;
//
//        node[] dfalist = DFA_Class.dfa_;
//        int num = DFA_Class.nodenum_;
//
//        Mini_DFA_Class.GetTable(num, dfalist);
//        Mini_DFA_Class.DrawMiniDFA();


        System.out.println("show GUI");

            frame show = new frame();

    }


}

class frame extends JFrame
{
    JPanel mypanel;
    JButton smile;
    JButton cry;
    JButton angry;
    JButton exit;
    JLabel mylabel;
    String nfa_path = "D:\\Graphviz\\NFA\\dotGif.jpg";
    String dfa_path = "D:\\Graphviz\\DFA\\dotGif.jpg";
    String minidfa_path = "D:\\Graphviz\\MiniDFA\\dotGif.jpg";


    public frame()
    {
        NFA NFA_Class = new NFA();
        DFA DFA_Class = new DFA();
        MiniDFA Mini_DFA_Class = new MiniDFA();

        String input = JOptionPane.showInputDialog("请输入正则表达式");
        InPoExClass InPoEx_Class = new InPoExClass(input);
        InPoEx_Class.Get_InPoExpression(InPoEx_Class);

        node[] Node = NFA_Class.resNfa(InPoEx_Class);

        DFA_Class.headnode = NFA_Class.headnode;
        DFA_Class.alphabeta_ = NFA_Class.alphabeta_;
        System.out.println("nfa headnode = " + DFA_Class.headnode);
        System.out.println("DFA alphabeta_： " + DFA_Class.alphabeta_);

        DFA_Class.draw_dfa(Node);

        Mini_DFA_Class.alphabeta_ = DFA_Class.alphabeta_;

        node[] dfalist = DFA_Class.dfa_;
        int num = DFA_Class.nodenum_;

        Mini_DFA_Class.GetTable(num, dfalist);
        Mini_DFA_Class.DrawMiniDFA();

        int width = 1800;
        int height = 600;
        int button_x = 50;
        int button_y = 450;
        mypanel = new JPanel();//创建面板组件
        getContentPane().add(mypanel,BorderLayout.CENTER);
        //先获取默认的内容面板,然后在默认内容面板的BorderLayout.CENTER位置增加frame面板
        mypanel.setLayout(null);//无默认排版
        //mypanel.setBounds(0,0,700,700);//面板大小位置
        this.setBounds(0,100,width,height);//设置窗体位置及大小,this可省略
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //用户单击关闭时程序执行
        setTitle("显示结果");//设置窗体标题
        setVisible(true);//设置窗体可见

        mylabel = new JLabel("Emoji");
        //JScrollPane jsp = new JScrollPane(new ScrollableLabel(ii));


        mypanel.add(mylabel);


        mylabel.setBounds(0,-50,width,height);

        //mylabel.setIcon(icon1);

        mylabel.setText("请点击按钮");
        mylabel.setFont(new Font(null, Font.PLAIN, 35));
        //设置NFA按钮
        smile = new JButton("NFA图");
        mypanel.add(smile);
        smile.setBounds(button_x,button_y,100,30);
        smile.addActionListener(new ActionListener()
        {//动作
            public void actionPerformed(ActionEvent e)
            {

                ImageIcon icon = new ImageIcon(nfa_path);
                int imgw = icon.getIconWidth();
                int imgh = icon.getIconHeight();

                icon=new ImageIcon(icon.getImage().getScaledInstance(1400, imgh, Image.SCALE_DEFAULT));
                mylabel.setIcon(icon);

            }
        });
        //设置MiniDFA按钮
        cry = new JButton("MiniDFA");
        mypanel.add(cry);
        cry.setBounds(250,button_y,100,30);
        cry.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                mylabel.setIcon(new ImageIcon(minidfa_path));
                mylabel.setSize(width, height);
            }
        });
        //设置DFA按钮
        angry = new JButton("DFA");
        mypanel.add(angry);
        angry.setBounds(450, button_y, 100, 30);
        angry.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                mylabel.setIcon(new ImageIcon(dfa_path));
            }
        });
        //退出
        exit = new JButton("退出");
        mypanel.add(exit);
        exit.setBounds(650, button_y, 60, 30);
        exit.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {

                System.exit(0);
            }
        });
    }

    public void next()
    {
        return;
    }

}







