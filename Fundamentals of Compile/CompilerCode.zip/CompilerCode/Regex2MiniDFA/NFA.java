package Regular_Expression;

import javax.swing.*;
import java.util.*;


/**
 * 封装的NFA生成与绘制函数
 *
 */


public class NFA extends InPoExClass
{

    public int headnode; //起始节点 本程序中即为倒数第二个节点 最终的节点数-1
    public Set<Character> alphabeta_ = new HashSet();
    //public input
    /*public static void main(String[] args)
    {
        NFA draw_nfa = new NFA();
        node[] Node = draw_nfa.resNfa();
    }*/

    NFA()
    {
        this.alphabeta_ = super.Get_alphabeta_();
    }

    public Set<Character> Get_alphabeta_()
    {
        return super.Get_alphabeta_();
    }

    public node[] resNfa(InPoExClass get)
    {
        /**
         * 记录了每两个节点之间的关系
         * 绘制NFA和生成DFA时使用
         */
        node[] Node = new node[100];

        Stack<nfanode> nfa = new Stack<nfanode>(); // 存储nfa的栈，仅在生成Node时使用

        //String input = JOptionPane.showInputDialog("请输入正则表达式");


        //Scanner scanner = new Scanner(System.in); // 输入流，后面用GUI代替
        //String input = scanner.next(); // 输入正则表达式
        //InPoExClass get = new InPoExClass(input); // 定义InPoExclass类型变量get

        //String input = "ab|c(d*|a)";
//        String input = "((a*)*|(b|a))*cd*";
//        InPoExClass get = new InPoExClass(input);
//        get.Get_InPoExpression(get);

        String InPo = get.outString;// 记录由正则表达式生成的逆波兰表达式

        System.out.println("NFA outstring= " + get.outString);
        this.alphabeta_ = get.Get_alphabeta_();
        System.out.println("NFA alphabeta:"+alphabeta_);
//        System.out.println("NFA: "+ this.alphabeta_);

        /**
         * 生成每个节点的current
         */
        for(int i = 0; i < 100; i++)
        {
            Node[i] = new node(i);
        }


        /*for(int i = 0; i < 100; i++)
        {
            System.out.println(Node[i].current);
        }*/



        /**
        如果是字母 则 1-a->2
        如果是.   则 由1-a->2, 3-b->4 到  5-*->1-a->2-yp->3-b->4-*->6

                                              1-a->2
        如果是|   则 由1-a->2, 3-b->4 到  5=*=>       =*=>6
                                              3-b->4

                                              <-*-
        如果是*   则 由1-a->2         到  3-*->1--a--2-*->4
                                          ------*------>
        */

        // 将逆波兰表达式转换为字符数组逐一处理生成nfa
        char[] a = new char[1000];
        InPo.getChars(0, InPo.length(), a, 0);

        int j = 0;// node的current值 每生成一个node j++

        for (int i = 0; i < InPo.length(); i++)
        {
            if(a[i] >= 'A' && a[i] <= 'z') //如果是字母 则 1-a->2
            {
                j++;
                Node[j] = new node(j); // 1
                Node[j].next.add(Node[j].current + 1);
                Node[j].way.append(a[i]);  // 1-a->2
                j++;
                Node[j] = new node(j); // 2

                nfanode cut = new nfanode(j-1, j);
                nfa.push(cut);
            }
            else  //如果是运算符则进行运算
            {
                nfanode second = new nfanode();
                nfanode first = new nfanode();
                nfanode cut = new nfanode();

                switch (a[i])
                {   // nfanode只有两个int src和int dst; node有int current、ArrayList next和StringBuffer way
                    case '.':
                        //如果是.   则 由1-a->2, 3-b->4 到  5-*->1-a->2-*->3-b->4-*->6
                        //second = new nfanode(); // 需要链接的第二个节点 3-b->4
                        second = nfa.peek();
                        nfa.pop();
                        //first = new nfanode(); // 需要连接的第一个节点 1-a->2
                        first = nfa.peek();
                        nfa.pop();

                        Node[first.dst].next.add(second.src);// 2-*->3
                        Node[first.dst].way.append('*');

                        j++;
                        Node[j] = new node(j);  // .运算后的起始节点5
                        Node[j].next.add(first.src); // 5-*->1
                        Node[j].way.append('*');

                        j++;
                        Node[j] = new node(j); //  .运算的结束节点6
                        Node[second.dst].next.add(j);// 4-*->6
                        Node[second.dst].way.append('*');

                        cut.set(j-1, j);
                        nfa.push(cut);
                        break;
                      /*                                     1-a->2
                        如果是|   则 由1-a->2, 3-b->4 到  5=*=>       =*=>6
                                                             3-b->4
                      */
                    case '|':
                        //second = new nfanode(); // 需要链接的第二个节点 3-b->4
                        second = nfa.peek();
                        nfa.pop();
                        //first = new nfanode(); // 需要连接的第一个节点 1-a->2
                        first = nfa.peek();
                        nfa.pop();

                        j++;
                        Node[j] = new node(j);
                        Node[j].next.add(first.src); // 5-*->1
                        Node[j].way.append('*');
                        Node[j].next.add(second.src); // 5-*->3
                        Node[j].way.append('*');

                        j++;
                        Node[j] = new node(j);
                        Node[first.dst].next.add(j); //2-*->6
                        Node[first.dst].way.append('*');

                        Node[second.dst].next.add(j); // 4-*->6
                        Node[second.dst].way.append('*');

                        cut.set(j-1, j);
                        nfa.push(cut);
                        break;

                        /*                                    <-*-
                        如果是*   则 由1-a->2         到  3-*->1--a--2-*->4
                                                         ------*------> */
                    case '*':

                        first = nfa.peek();
                        nfa.pop();

                        j++;
                        Node[j] = new node(j);
                        Node[j].next.add(first.src);//3-*->1
                        Node[j].way.append('*');
                        Node[j].next.add(j+1); //3-*->4
                        Node[j].way.append('*');

                        j++;
                        Node[j] = new node(j);
                        Node[first.dst].next.add(j); //2-*->4
                        Node[first.dst].way.append('*');
                        Node[first.dst].next.add(first.src); // 2-*->1
                        Node[first.dst].way.append('*');

                        cut.set(j-1,j);
                        nfa.push(cut);
                }//switch
            }//else
        }//for

        int lenth = j; // lenth 保存当前共有多少个node
        this.headnode = j-1;

        GraphVizTest gViz=new GraphVizTest("D:\\Graphviz\\NFA", "D:\\Graphviz\\bin\\dot.exe");
        gViz.start_graph();
        gViz.addln("graph [rankdir=LR];");
        for(int i = 1; i <= lenth; i++)
        {
            for(int k = 0; k < Node[i].next.size(); k++)//k记录每个node有多少个next
            {
                String out = new String();
                out += Node[i].current + "->" + Node[i].next.get(k)+ " [label = ";

                char c = Node[i].way.charAt(k);
                if(c != '*')
                    out += String.valueOf(c);
                else
                    out += "ε";
                out += "];";
                //gViz.addln(Node[i].current + "->" + Node[i].next.get(k)+ " [label = "+ Node[i].way.substring(k) +"];");
                gViz.addln(out);
                //System.out.println(Node[i].current + "->" + Node[i].next.get(k));
            }

        }

        gViz.end_graph();
        try {
            gViz.run();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Node;

    }
}

